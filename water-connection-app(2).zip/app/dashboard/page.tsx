"use client"

import { Sidebar } from "@/components/sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { FileText, Clock, CheckCircle, AlertCircle, Plus } from "lucide-react"
import Link from "next/link"

export default function CustomerDashboard() {
  const recentApplications = [
    {
      id: "WC2024001",
      type: "Residential",
      status: "Under Review",
      statusColor: "bg-yellow-100 text-yellow-800",
      submittedDate: "2024-01-15",
      address: "123 Main Street, Springfield",
    },
    {
      id: "WC2024002",
      type: "Commercial",
      status: "Approved",
      statusColor: "bg-green-100 text-green-800",
      submittedDate: "2024-01-10",
      address: "456 Business Ave, Springfield",
    },
  ]

  const quickStats = [
    {
      title: "Total Applications",
      value: "2",
      icon: FileText,
      color: "text-blue-600",
    },
    {
      title: "Pending Review",
      value: "1",
      icon: Clock,
      color: "text-yellow-600",
    },
    {
      title: "Approved",
      value: "1",
      icon: CheckCircle,
      color: "text-green-600",
    },
    {
      title: "Issues",
      value: "0",
      icon: AlertCircle,
      color: "text-red-600",
    },
  ]

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar userRole="customer" />

      <div className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-2">
              Welcome back! Here's an overview of your water connection applications.
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {quickStats.map((stat, index) => {
              const Icon = stat.icon
              return (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                        <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      </div>
                      <div
                        className={`p-2 rounded-lg ${
                          stat.color === "text-blue-600"
                            ? "bg-blue-100"
                            : stat.color === "text-yellow-600"
                              ? "bg-yellow-100"
                              : stat.color === "text-green-600"
                                ? "bg-green-100"
                                : "bg-red-100"
                        }`}
                      >
                        <Icon className={`h-6 w-6 ${stat.color}`} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Recent Applications */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Recent Applications</CardTitle>
                <CardDescription>Your latest water connection requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentApplications.map((app, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="font-semibold text-gray-900">{app.id}</h3>
                          <Badge className={app.statusColor}>{app.status}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{app.type} Connection</p>
                        <p className="text-sm text-gray-500">{app.address}</p>
                        <p className="text-xs text-gray-400 mt-2">Submitted: {app.submittedDate}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="mt-6 text-center">
                  <Link href="/applications">
                    <Button variant="outline">View All Applications</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common tasks and shortcuts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link href="/application/new">
                  <Button className="w-full justify-start" variant="outline">
                    <Plus className="mr-2 h-4 w-4" />
                    New Application
                  </Button>
                </Link>

                <Link href="/applications">
                  <Button className="w-full justify-start" variant="outline">
                    <FileText className="mr-2 h-4 w-4" />
                    Track Applications
                  </Button>
                </Link>

                <Link href="/payments">
                  <Button className="w-full justify-start" variant="outline">
                    <Clock className="mr-2 h-4 w-4" />
                    Payment History
                  </Button>
                </Link>

                <Link href="/support">
                  <Button className="w-full justify-start" variant="outline">
                    <AlertCircle className="mr-2 h-4 w-4" />
                    Get Support
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
