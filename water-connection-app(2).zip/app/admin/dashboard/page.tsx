"use client"

import { Sidebar } from "@/components/sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Shield, FileText, Database, Zap } from "lucide-react"

export default function AdminDashboard() {
  const metrics = [
    {
      title: "User Management",
      value: "1345",
      icon: Users,
      description: "Total registered users",
      action: "View",
    },
    {
      title: "Security",
      value: "3",
      icon: Shield,
      description: "Active security alerts",
      action: "View",
    },
    {
      title: "Audit Logs",
      value: "1452",
      icon: FileText,
      description: "System audit entries",
      action: "View",
    },
    {
      title: "Backup & Restore",
      value: "24",
      icon: Database,
      description: "Available backups",
      action: "View",
    },
    {
      title: "API Integration",
      value: "8",
      icon: Zap,
      description: "Active integrations",
      action: "View",
    },
  ]

  const systemStatus = {
    uptime: "99.98%",
    activeUsers: "143",
    databaseSize: "1.2 TB",
    lastBackup: "2023-05-14 03:00 AM",
    apiRequests: "2.4K/day",
    serverLoad: 42,
  }

  const userDistribution = [
    { type: "Customers", percentage: 92, color: "bg-green-500" },
    { type: "Staff", percentage: 6, color: "bg-blue-500" },
    { type: "Admin", percentage: 1, color: "bg-pink-500" },
    { type: "Management", percentage: 1, color: "bg-orange-500" },
  ]

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar userRole="admin" />

      <div className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">NRWB Portal</h1>
            <p className="text-gray-600 mt-2">System overview, security status, and user management</p>
          </div>

          {/* Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
            {metrics.map((metric, index) => {
              const Icon = metric.icon
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Icon className="h-6 w-6 text-blue-600" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-semibold text-gray-900">{metric.title}</h3>
                      <div className="text-2xl font-bold text-gray-900">{metric.value}</div>
                      <p className="text-sm text-gray-600">{metric.description}</p>
                      <Button variant="outline" size="sm" className="w-full mt-3">
                        {metric.action} →
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* System Status */}
            <Card>
              <CardHeader>
                <CardTitle>System Status</CardTitle>
                <CardDescription>Current system metrics and performance</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Uptime</p>
                    <p className="text-2xl font-bold text-green-600">{systemStatus.uptime}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">Active Sessions</p>
                    <p className="text-2xl font-bold text-gray-900">{systemStatus.activeUsers}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">Database Size</p>
                    <p className="text-2xl font-bold text-gray-900">{systemStatus.databaseSize}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">Last Backup</p>
                    <p className="text-sm text-gray-900">{systemStatus.lastBackup}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">API Requests</p>
                    <p className="text-2xl font-bold text-gray-900">{systemStatus.apiRequests}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">Server Load</p>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${systemStatus.serverLoad}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{systemStatus.serverLoad}%</span>
                    </div>
                  </div>
                </div>

                <Button className="w-full mt-6">View System Configuration</Button>
              </CardContent>
            </Card>

            {/* User Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>User Distribution</CardTitle>
                <CardDescription>Breakdown of system user types</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {userDistribution.map((user, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${user.color}`} />
                        <span className="font-medium">{user.type}</span>
                      </div>
                      <span className="font-bold">{user.percentage}%</span>
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex justify-center">
                  <div className="relative w-48 h-48">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke="#10b981"
                        strokeWidth="20"
                        strokeDasharray="230 250"
                        transform="rotate(-90 50 50)"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke="#3b82f6"
                        strokeWidth="20"
                        strokeDasharray="15 250"
                        strokeDashoffset="-230"
                        transform="rotate(-90 50 50)"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke="#ec4899"
                        strokeWidth="20"
                        strokeDasharray="2.5 250"
                        strokeDashoffset="-245"
                        transform="rotate(-90 50 50)"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke="#f97316"
                        strokeWidth="20"
                        strokeDasharray="2.5 250"
                        strokeDashoffset="-247.5"
                        transform="rotate(-90 50 50)"
                      />
                    </svg>
                  </div>
                </div>

                <Button className="w-full mt-6">Manage Users</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
