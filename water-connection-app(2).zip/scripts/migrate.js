const { pool } = require("../lib/db")

async function runMigrations() {
  const client = await pool.connect()

  try {
    console.log("🚀 Running database migrations...")

    // Create users table
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        phone VARCHAR(20) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(20) DEFAULT 'customer' CHECK (role IN ('customer', 'staff', 'admin', 'manager')),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create applications table
    await client.query(`
      CREATE TABLE IF NOT EXISTS applications (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        application_number VARCHAR(20) UNIQUE NOT NULL,
        property_type VARCHAR(20) NOT NULL CHECK (property_type IN ('residential', 'commercial', 'industrial', 'institutional')),
        property_use VARCHAR(50),
        address TEXT NOT NULL,
        city VARCHAR(100) NOT NULL,
        district VARCHAR(100),
        postal_code VARCHAR(10),
        ownership_status VARCHAR(20) CHECK (ownership_status IN ('owner', 'tenant', 'agent', 'other')),
        connection_type VARCHAR(20) NOT NULL CHECK (connection_type IN ('standard', 'medium', 'large')),
        expected_usage INTEGER,
        additional_info TEXT,
        status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'under_review', 'approved', 'rejected', 'completed')),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create application_status_history table
    await client.query(`
      CREATE TABLE IF NOT EXISTS application_status_history (
        id SERIAL PRIMARY KEY,
        application_id INTEGER REFERENCES applications(id) ON DELETE CASCADE,
        status VARCHAR(20) NOT NULL,
        comment TEXT,
        changed_by VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create payments table
    await client.query(`
      CREATE TABLE IF NOT EXISTS payments (
        id SERIAL PRIMARY KEY,
        application_id INTEGER REFERENCES applications(id) ON DELETE CASCADE,
        amount DECIMAL(10,2) NOT NULL,
        payment_type VARCHAR(20) NOT NULL CHECK (payment_type IN ('application_fee', 'connection_fee', 'deposit')),
        payment_method VARCHAR(20) CHECK (payment_method IN ('credit_card', 'bank_transfer', 'cash', 'mobile_money')),
        payment_status VARCHAR(20) DEFAULT 'pending' CHECK (payment_status IN ('pending', 'completed', 'failed', 'refunded')),
        transaction_id VARCHAR(100),
        paid_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create documents table
    await client.query(`
      CREATE TABLE IF NOT EXISTS documents (
        id SERIAL PRIMARY KEY,
        application_id INTEGER REFERENCES applications(id) ON DELETE CASCADE,
        document_type VARCHAR(50) NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        file_size INTEGER,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create indexes
    await client.query("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)")
    await client.query("CREATE INDEX IF NOT EXISTS idx_applications_user_id ON applications(user_id)")
    await client.query("CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status)")
    await client.query("CREATE INDEX IF NOT EXISTS idx_applications_number ON applications(application_number)")

    // Create update trigger function
    await client.query(`
      CREATE OR REPLACE FUNCTION update_updated_at_column()
      RETURNS TRIGGER AS $$
      BEGIN
        NEW.updated_at = CURRENT_TIMESTAMP;
        RETURN NEW;
      END;
      $$ language 'plpgsql'
    `)

    // Create triggers
    await client.query(`
      DROP TRIGGER IF EXISTS update_users_updated_at ON users;
      CREATE TRIGGER update_users_updated_at 
        BEFORE UPDATE ON users
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()
    `)

    await client.query(`
      DROP TRIGGER IF EXISTS update_applications_updated_at ON applications;
      CREATE TRIGGER update_applications_updated_at 
        BEFORE UPDATE ON applications
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()
    `)

    console.log("✅ Database migrations completed successfully")
  } catch (error) {
    console.error("❌ Migration failed:", error)
    throw error
  } finally {
    client.release()
  }
}

// Run migrations if called directly
if (require.main === module) {
  runMigrations()
    .then(() => {
      console.log("🎉 All migrations completed")
      process.exit(0)
    })
    .catch((error) => {
      console.error("💥 Migration failed:", error)
      process.exit(1)
    })
}

module.exports = { runMigrations }
