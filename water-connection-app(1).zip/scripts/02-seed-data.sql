-- Insert sample users
INSERT INTO users (first_name, last_name, email, phone, password_hash) VALUES
('John', 'Doe', 'john.doe@example.com', '+1234567890', '$2b$10$example_hash_1'),
('Jane', 'Smith', 'jane.smith@example.com', '+1234567891', '$2b$10$example_hash_2'),
('Mike', 'Johnson', 'mike.johnson@example.com', '+1234567892', '$2b$10$example_hash_3');

-- Insert sample applications
INSERT INTO applications (user_id, application_number, property_type, address, city, postal_code, connection_type, expected_usage, status) VALUES
(1, 'WC2024001', 'residential', '123 Main Street, Apt 4B', 'Springfield', '12345', 'standard', 3000, 'pending'),
(2, 'WC2024002', 'commercial', '456 Business Ave, Suite 200', 'Springfield', '12346', 'large', 15000, 'under_review'),
(3, 'WC2024003', 'residential', '789 Oak Drive', 'Springfield', '12347', 'medium', 5000, 'approved');

-- Insert sample application status history
INSERT INTO application_status_history (application_id, status, comment, changed_by) VALUES
(1, 'pending', 'Application submitted', 'system'),
(2, 'pending', 'Application submitted', 'system'),
(2, 'under_review', 'Application under technical review', 'admin'),
(3, 'pending', 'Application submitted', 'system'),
(3, 'under_review', 'Application under review', 'admin'),
(3, 'approved', 'Application approved for connection', 'admin');

-- Insert sample payments
INSERT INTO payments (application_id, amount, payment_type, payment_method, payment_status, transaction_id, paid_at) VALUES
(1, 50.00, 'application_fee', 'credit_card', 'completed', 'TXN001', CURRENT_TIMESTAMP - INTERVAL '1 day'),
(2, 50.00, 'application_fee', 'bank_transfer', 'completed', 'TXN002', CURRENT_TIMESTAMP - INTERVAL '2 days'),
(3, 50.00, 'application_fee', 'credit_card', 'completed', 'TXN003', CURRENT_TIMESTAMP - INTERVAL '3 days'),
(3, 200.00, 'connection_fee', 'credit_card', 'completed', 'TXN004', CURRENT_TIMESTAMP - INTERVAL '1 day');
