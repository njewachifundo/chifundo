const { pool } = require("../lib/db")
const bcrypt = require("bcryptjs")

async function seedDatabase() {
  const client = await pool.connect()

  try {
    console.log("🌱 Seeding database...")

    // Hash passwords
    const customerPassword = await bcrypt.hash("password1", 10)
    const staffPassword = await bcrypt.hash("password1", 10)
    const adminPassword = await bcrypt.hash("password1", 10)
    const managerPassword = await bcrypt.hash("password1", 10)

    // Insert demo users
    await client.query(
      `
      INSERT INTO users (first_name, last_name, email, phone, password_hash, role) VALUES
      ('John', 'Customer', 'customer1@nrwb.com', '+265991234567', $1, 'customer'),
      ('Jane', 'Staff', 'staff1@nrwb.com', '+265991234568', $2, 'staff'),
      ('Admin', 'User', 'admin1@nrwb.com', '+265991234569', $3, 'admin'),
      ('Manager', 'User', 'manager1@nrwb.com', '+265991234570', $4, 'manager')
      ON CONFLICT (email) DO NOTHING
    `,
      [customerPassword, staffPassword, adminPassword, managerPassword],
    )

    // Get user IDs
    const customerResult = await client.query("SELECT id FROM users WHERE email = $1", ["customer1@nrwb.com"])
    const customerId = customerResult.rows[0]?.id

    if (customerId) {
      // Insert sample applications
      await client.query(
        `
        INSERT INTO applications (
          user_id, application_number, property_type, property_use, address, city, district, 
          ownership_status, connection_type, expected_usage, status
        ) VALUES
        ($1, 'WC2024001', 'residential', 'single_family', '123 Main Street, Lilongwe', 'Lilongwe', 'north', 'owner', 'standard', 3000, 'pending'),
        ($1, 'WC2024002', 'commercial', 'office', '456 Business Ave, Blantyre', 'Blantyre', 'south', 'owner', 'large', 15000, 'under_review')
        ON CONFLICT (application_number) DO NOTHING
      `,
        [customerId],
      )

      // Get application IDs
      const appResult = await client.query("SELECT id, application_number FROM applications WHERE user_id = $1", [
        customerId,
      ])

      for (const app of appResult.rows) {
        // Insert status history
        await client.query(
          `
          INSERT INTO application_status_history (application_id, status, comment, changed_by) VALUES
          ($1, 'pending', 'Application submitted', 'system')
          ON CONFLICT DO NOTHING
        `,
          [app.id],
        )

        // Insert sample payment
        await client.query(
          `
          INSERT INTO payments (application_id, amount, payment_type, payment_method, payment_status, transaction_id, paid_at) VALUES
          ($1, 50.00, 'application_fee', 'mobile_money', 'completed', $2, CURRENT_TIMESTAMP)
          ON CONFLICT DO NOTHING
        `,
          [app.id, `TXN${app.application_number}`],
        )
      }
    }

    console.log("✅ Database seeded successfully")
    console.log("🔑 Demo login credentials:")
    console.log("   Customer: customer1@nrwb.com / password1")
    console.log("   Staff: staff1@nrwb.com / password1")
    console.log("   Admin: admin1@nrwb.com / password1")
    console.log("   Manager: manager1@nrwb.com / password1")
  } catch (error) {
    console.error("❌ Seeding failed:", error)
    throw error
  } finally {
    client.release()
  }
}

// Run seeding if called directly
if (require.main === module) {
  seedDatabase()
    .then(() => {
      console.log("🎉 Database seeding completed")
      process.exit(0)
    })
    .catch((error) => {
      console.error("💥 Seeding failed:", error)
      process.exit(1)
    })
}

module.exports = { seedDatabase }
