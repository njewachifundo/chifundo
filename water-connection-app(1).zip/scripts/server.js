const express = require("express")
const cors = require("cors")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const { Pool } = require("pg")
require("dotenv").config()

const app = express()
const port = process.env.PORT || 3001

// Database connection
const pool = new Pool({
  user: process.env.DB_USER || "postgres",
  host: process.env.DB_HOST || "localhost",
  database: process.env.DB_NAME || "water_connection_db",
  password: process.env.DB_PASSWORD || "password",
  port: process.env.DB_PORT || 5432,
})

// Middleware
app.use(cors())
app.use(express.json())

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.status(401).json({ error: "Access token required" })
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: "Invalid token" })
    }
    req.user = user
    next()
  })
}

// Generate application number
const generateApplicationNumber = () => {
  const year = new Date().getFullYear()
  const random = Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, "0")
  return `WC${year}${random}`
}

// Routes

// User Registration
app.post("/api/auth/register", async (req, res) => {
  try {
    const { firstName, lastName, email, phone, password } = req.body

    // Check if user already exists
    const existingUser = await pool.query("SELECT id FROM users WHERE email = $1", [email])
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: "User already exists with this email" })
    }

    // Hash password
    const saltRounds = 10
    const passwordHash = await bcrypt.hash(password, saltRounds)

    // Insert new user
    const result = await pool.query(
      "INSERT INTO users (first_name, last_name, email, phone, password_hash) VALUES ($1, $2, $3, $4, $5) RETURNING id, first_name, last_name, email",
      [firstName, lastName, email, phone, passwordHash],
    )

    const user = result.rows[0]

    // Generate JWT token
    const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: "24h" })

    res.status(201).json({
      message: "User registered successfully",
      user: {
        id: user.id,
        firstName: user.first_name,
        lastName: user.last_name,
        email: user.email,
      },
      token,
    })
  } catch (error) {
    console.error("Registration error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// User Login
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body

    // Find user
    const result = await pool.query("SELECT * FROM users WHERE email = $1", [email])
    if (result.rows.length === 0) {
      return res.status(401).json({ error: "Invalid credentials" })
    }

    const user = result.rows[0]

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password_hash)
    if (!isValidPassword) {
      return res.status(401).json({ error: "Invalid credentials" })
    }

    // Generate JWT token
    const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: "24h" })

    res.json({
      message: "Login successful",
      user: {
        id: user.id,
        firstName: user.first_name,
        lastName: user.last_name,
        email: user.email,
      },
      token,
    })
  } catch (error) {
    console.error("Login error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Submit Application
app.post("/api/applications", authenticateToken, async (req, res) => {
  try {
    const { propertyType, address, city, postalCode, connectionType, expectedUsage, additionalInfo } = req.body
    const userId = req.user.userId

    const applicationNumber = generateApplicationNumber()

    const result = await pool.query(
      `INSERT INTO applications (user_id, application_number, property_type, address, city, postal_code, connection_type, expected_usage, additional_info)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [
        userId,
        applicationNumber,
        propertyType,
        address,
        city,
        postalCode,
        connectionType,
        expectedUsage,
        additionalInfo,
      ],
    )

    const application = result.rows[0]

    // Add initial status history
    await pool.query(
      "INSERT INTO application_status_history (application_id, status, comment, changed_by) VALUES ($1, $2, $3, $4)",
      [application.id, "pending", "Application submitted", "system"],
    )

    res.status(201).json({
      message: "Application submitted successfully",
      application: {
        id: application.id,
        applicationNumber: application.application_number,
        status: application.status,
        createdAt: application.created_at,
      },
    })
  } catch (error) {
    console.error("Application submission error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Get User Applications
app.get("/api/applications", authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId

    const result = await pool.query(
      `SELECT a.*, 
              COALESCE(SUM(p.amount), 0) as total_paid,
              COUNT(d.id) as document_count
       FROM applications a
       LEFT JOIN payments p ON a.id = p.application_id AND p.payment_status = 'completed'
       LEFT JOIN documents d ON a.id = d.application_id
       WHERE a.user_id = $1
       GROUP BY a.id
       ORDER BY a.created_at DESC`,
      [userId],
    )

    res.json({
      applications: result.rows.map((app) => ({
        id: app.id,
        applicationNumber: app.application_number,
        propertyType: app.property_type,
        address: app.address,
        city: app.city,
        postalCode: app.postal_code,
        connectionType: app.connection_type,
        expectedUsage: app.expected_usage,
        status: app.status,
        totalPaid: Number.parseFloat(app.total_paid),
        documentCount: Number.parseInt(app.document_count),
        createdAt: app.created_at,
        updatedAt: app.updated_at,
      })),
    })
  } catch (error) {
    console.error("Get applications error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Get Application Details
app.get("/api/applications/:id", authenticateToken, async (req, res) => {
  try {
    const applicationId = req.params.id
    const userId = req.user.userId

    // Get application details
    const appResult = await pool.query("SELECT * FROM applications WHERE id = $1 AND user_id = $2", [
      applicationId,
      userId,
    ])

    if (appResult.rows.length === 0) {
      return res.status(404).json({ error: "Application not found" })
    }

    const application = appResult.rows[0]

    // Get status history
    const historyResult = await pool.query(
      "SELECT * FROM application_status_history WHERE application_id = $1 ORDER BY created_at DESC",
      [applicationId],
    )

    // Get payments
    const paymentsResult = await pool.query(
      "SELECT * FROM payments WHERE application_id = $1 ORDER BY created_at DESC",
      [applicationId],
    )

    res.json({
      application: {
        id: application.id,
        applicationNumber: application.application_number,
        propertyType: application.property_type,
        address: application.address,
        city: application.city,
        postalCode: application.postal_code,
        connectionType: application.connection_type,
        expectedUsage: application.expected_usage,
        additionalInfo: application.additional_info,
        status: application.status,
        createdAt: application.created_at,
        updatedAt: application.updated_at,
      },
      statusHistory: historyResult.rows,
      payments: paymentsResult.rows,
    })
  } catch (error) {
    console.error("Get application details error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Create Payment
app.post("/api/payments", authenticateToken, async (req, res) => {
  try {
    const { applicationId, amount, paymentType, paymentMethod } = req.body
    const userId = req.user.userId

    // Verify application belongs to user
    const appResult = await pool.query("SELECT id FROM applications WHERE id = $1 AND user_id = $2", [
      applicationId,
      userId,
    ])

    if (appResult.rows.length === 0) {
      return res.status(404).json({ error: "Application not found" })
    }

    // Generate transaction ID
    const transactionId = `TXN${Date.now()}${Math.floor(Math.random() * 1000)}`

    const result = await pool.query(
      `INSERT INTO payments (application_id, amount, payment_type, payment_method, payment_status, transaction_id, paid_at)
       VALUES ($1, $2, $3, $4, 'completed', $5, CURRENT_TIMESTAMP) RETURNING *`,
      [applicationId, amount, paymentType, paymentMethod, transactionId],
    )

    res.status(201).json({
      message: "Payment processed successfully",
      payment: result.rows[0],
    })
  } catch (error) {
    console.error("Payment processing error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "OK", timestamp: new Date().toISOString() })
})

// Start server
app.listen(port, () => {
  console.log(`Water Connection API server running on port ${port}`)
})
