"use client"

import { Sidebar } from "@/components/sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DollarSign, TrendingUp, Clock, Users } from "lucide-react"

export default function ManagerDashboard() {
  const metrics = [
    {
      title: "Revenue (MTD)",
      value: "MK 22.4M",
      change: "+12.5% from last month",
      changeType: "positive",
      icon: DollarSign,
      color: "text-green-600",
    },
    {
      title: "New Connections (MTD)",
      value: "145",
      change: "+8.2% from last month",
      changeType: "positive",
      icon: TrendingUp,
      color: "text-blue-600",
    },
    {
      title: "Avg. Processing Time",
      value: "3.2 days",
      change: "+0.5 days from target",
      changeType: "negative",
      icon: Clock,
      color: "text-purple-600",
    },
    {
      title: "Customer Satisfaction",
      value: "87%",
      change: "-3% from target",
      changeType: "negative",
      icon: Users,
      color: "text-orange-600",
    },
  ]

  const applicationDistribution = [
    { type: "Residential", percentage: 68, color: "bg-green-500" },
    { type: "Commercial", percentage: 22, color: "bg-blue-500" },
    { type: "Industrial", percentage: 7, color: "bg-pink-500" },
    { type: "Institutional", percentage: 3, color: "bg-orange-500" },
  ]

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar userRole="manager" />

      <div className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Executive Dashboard</h1>
            <p className="text-gray-600 mt-2">Strategic overview, performance metrics, and financial insights</p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {metrics.map((metric, index) => {
              const Icon = metric.icon
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div
                        className={`p-2 rounded-lg ${
                          metric.color === "text-green-600"
                            ? "bg-green-100"
                            : metric.color === "text-blue-600"
                              ? "bg-blue-100"
                              : metric.color === "text-purple-600"
                                ? "bg-purple-100"
                                : "bg-orange-100"
                        }`}
                      >
                        <Icon className={`h-6 w-6 ${metric.color}`} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-semibold text-gray-600 text-sm">{metric.title}</h3>
                      <div className="text-2xl font-bold text-gray-900">{metric.value}</div>
                      <p className={`text-sm ${metric.changeType === "positive" ? "text-green-600" : "text-red-600"}`}>
                        {metric.change}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Revenue Trends Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Revenue Trends</CardTitle>
                <CardDescription>Actual vs projected revenue</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-end justify-between space-x-2 mb-4">
                  {/* Simplified chart representation */}
                  <div className="flex flex-col items-center space-y-2">
                    <div className="w-8 bg-green-500 rounded-t" style={{ height: "120px" }}></div>
                    <span className="text-xs text-gray-600">Jan</span>
                  </div>
                  <div className="flex flex-col items-center space-y-2">
                    <div className="w-8 bg-green-500 rounded-t" style={{ height: "100px" }}></div>
                    <span className="text-xs text-gray-600">Feb</span>
                  </div>
                  <div className="flex flex-col items-center space-y-2">
                    <div className="w-8 bg-green-500 rounded-t" style={{ height: "140px" }}></div>
                    <span className="text-xs text-gray-600">Mar</span>
                  </div>
                  <div className="flex flex-col items-center space-y-2">
                    <div className="w-8 bg-green-500 rounded-t" style={{ height: "130px" }}></div>
                    <span className="text-xs text-gray-600">Apr</span>
                  </div>
                  <div className="flex flex-col items-center space-y-2">
                    <div className="w-8 bg-green-500 rounded-t" style={{ height: "160px" }}></div>
                    <span className="text-xs text-gray-600">May</span>
                  </div>
                  <div className="flex flex-col items-center space-y-2">
                    <div className="w-8 bg-green-500 rounded-t" style={{ height: "150px" }}></div>
                    <span className="text-xs text-gray-600">Jun</span>
                  </div>
                </div>
                <div className="flex items-center justify-center space-x-6 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>Actual Revenue</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                    <span>Projected Revenue</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Application Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Application Distribution</CardTitle>
                <CardDescription>Connection types breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-6">
                  {applicationDistribution.map((app, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${app.color}`} />
                        <span className="font-medium">{app.type}</span>
                      </div>
                      <span className="font-bold">{app.percentage}%</span>
                    </div>
                  ))}
                </div>

                <div className="flex justify-center">
                  <div className="relative w-40 h-40">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="35"
                        fill="none"
                        stroke="#10b981"
                        strokeWidth="15"
                        strokeDasharray="170 250"
                        transform="rotate(-90 50 50)"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="35"
                        fill="none"
                        stroke="#3b82f6"
                        strokeWidth="15"
                        strokeDasharray="55 250"
                        strokeDashoffset="-170"
                        transform="rotate(-90 50 50)"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="35"
                        fill="none"
                        stroke="#ec4899"
                        strokeWidth="15"
                        strokeDasharray="17.5 250"
                        strokeDashoffset="-225"
                        transform="rotate(-90 50 50)"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="35"
                        fill="none"
                        stroke="#f97316"
                        strokeWidth="15"
                        strokeDasharray="7.5 250"
                        strokeDashoffset="-242.5"
                        transform="rotate(-90 50 50)"
                      />
                    </svg>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
