"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Upload, ChevronLeft, ChevronRight } from "lucide-react"

export default function NewApplicationPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState({
    // Personal Details
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    idType: "",
    idNumber: "",
    // Property Information
    propertyType: "",
    propertyUse: "",
    streetAddress: "",
    cityTown: "",
    district: "",
    ownershipStatus: "",
  })

  const steps = [
    { number: 1, title: "Personal Details", description: "Provide your personal contact information" },
    { number: 2, title: "Property Information", description: "Tell us about your property" },
    { number: 3, title: "Document Upload", description: "Upload required documentation" },
    { number: 4, title: "Location", description: "Specify connection location" },
    { number: 5, title: "Review & Submit", description: "Review and submit your application" },
  ]

  const handleInputChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const nextStep = () => {
    if (currentStep < 5) setCurrentStep(currentStep + 1)
  }

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1)
  }

  const renderStepIndicator = () => (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        {steps.map((step, index) => (
          <div key={step.number} className="flex flex-col items-center">
            <div
              className={`w-12 h-12 rounded-full flex items-center justify-center text-sm font-medium ${
                step.number === currentStep
                  ? "bg-blue-600 text-white"
                  : step.number < currentStep
                    ? "bg-blue-600 text-white"
                    : "bg-gray-200 text-gray-600"
              }`}
            >
              {step.number}
            </div>
            <div className="mt-2 text-center">
              <p className={`text-sm font-medium ${step.number === currentStep ? "text-blue-600" : "text-gray-500"}`}>
                {step.title}
              </p>
            </div>
          </div>
        ))}
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
          style={{ width: `${(currentStep / 5) * 100}%` }}
        />
      </div>
    </div>
  )

  const renderPersonalDetails = () => (
    <Card>
      <CardHeader>
        <CardTitle>Personal Details</CardTitle>
        <CardDescription>Provide your personal contact information</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="firstName">First Name</Label>
            <Input
              id="firstName"
              placeholder="Enter your first name"
              value={formData.firstName}
              onChange={(e) => handleInputChange("firstName", e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="lastName">Last Name</Label>
            <Input
              id="lastName"
              placeholder="Enter your last name"
              value={formData.lastName}
              onChange={(e) => handleInputChange("lastName", e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter your email address"
              value={formData.email}
              onChange={(e) => handleInputChange("email", e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              placeholder="Enter your phone number"
              value={formData.phone}
              onChange={(e) => handleInputChange("phone", e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="idType">ID Type</Label>
            <Select value={formData.idType} onValueChange={(value) => handleInputChange("idType", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select ID Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="national_id">National ID</SelectItem>
                <SelectItem value="passport">Passport</SelectItem>
                <SelectItem value="drivers_license">Driver's License</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="idNumber">ID Number</Label>
            <Input
              id="idNumber"
              placeholder="Enter your ID number"
              value={formData.idNumber}
              onChange={(e) => handleInputChange("idNumber", e.target.value)}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const renderPropertyInformation = () => (
    <Card>
      <CardHeader>
        <CardTitle>Property Information</CardTitle>
        <CardDescription>Tell us about your property</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="propertyType">Property Type</Label>
            <Select value={formData.propertyType} onValueChange={(value) => handleInputChange("propertyType", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select Property Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="residential">Residential</SelectItem>
                <SelectItem value="commercial">Commercial</SelectItem>
                <SelectItem value="industrial">Industrial</SelectItem>
                <SelectItem value="institutional">Institutional</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="propertyUse">Property Use</Label>
            <Select value={formData.propertyUse} onValueChange={(value) => handleInputChange("propertyUse", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select Property Use" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="single_family">Single Family</SelectItem>
                <SelectItem value="multi_family">Multi Family</SelectItem>
                <SelectItem value="office">Office</SelectItem>
                <SelectItem value="retail">Retail</SelectItem>
                <SelectItem value="warehouse">Warehouse</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label htmlFor="streetAddress">Street Address</Label>
          <Textarea
            id="streetAddress"
            placeholder="Enter the property address"
            value={formData.streetAddress}
            onChange={(e) => handleInputChange("streetAddress", e.target.value)}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="cityTown">City/Town</Label>
            <Input
              id="cityTown"
              placeholder="Enter city or town"
              value={formData.cityTown}
              onChange={(e) => handleInputChange("cityTown", e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="district">District</Label>
            <Select value={formData.district} onValueChange={(value) => handleInputChange("district", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select District" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="north">North District</SelectItem>
                <SelectItem value="south">South District</SelectItem>
                <SelectItem value="east">East District</SelectItem>
                <SelectItem value="west">West District</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label>Ownership Status</Label>
          <RadioGroup
            value={formData.ownershipStatus}
            onValueChange={(value) => handleInputChange("ownershipStatus", value)}
            className="grid grid-cols-2 gap-4 mt-2"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="owner" id="owner" />
              <Label htmlFor="owner">Property Owner</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="tenant" id="tenant" />
              <Label htmlFor="tenant">Tenant</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="agent" id="agent" />
              <Label htmlFor="agent">Agent/Representative</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="other" id="other" />
              <Label htmlFor="other">Other</Label>
            </div>
          </RadioGroup>
        </div>
      </CardContent>
    </Card>
  )

  const renderDocumentUpload = () => (
    <Card>
      <CardHeader>
        <CardTitle>Document Upload</CardTitle>
        <CardDescription>Upload required documentation</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label className="text-base font-medium">ID Document (National ID, Passport, etc.)</Label>
          <div className="mt-2 border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors">
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
            <div className="mt-4">
              <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                Click to upload
              </Button>
            </div>
            <p className="mt-2 text-sm text-gray-500">PDF, JPG, JPEG or PNG (Max 5MB)</p>
          </div>
        </div>

        <div>
          <Label className="text-base font-medium">Property Ownership Document</Label>
          <div className="mt-2 border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors">
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
            <div className="mt-4">
              <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                Click to upload
              </Button>
            </div>
            <p className="mt-2 text-sm text-gray-500">Title deed, rental agreement, etc. (Max 5MB)</p>
          </div>
        </div>

        <div>
          <Label className="text-base font-medium">Additional Documents (Optional)</Label>
          <div className="mt-2 border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors">
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
            <div className="mt-4">
              <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                Click to upload
              </Button>
            </div>
            <p className="mt-2 text-sm text-gray-500">Any other supporting documents (Max 5MB)</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return renderPersonalDetails()
      case 2:
        return renderPropertyInformation()
      case 3:
        return renderDocumentUpload()
      case 4:
        return (
          <Card>
            <CardContent className="p-8 text-center">Location step coming soon...</CardContent>
          </Card>
        )
      case 5:
        return (
          <Card>
            <CardContent className="p-8 text-center">Review & Submit step coming soon...</CardContent>
          </Card>
        )
      default:
        return renderPersonalDetails()
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar userRole="customer" />

      <div className="flex-1 p-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">New Water Connection Application</h1>
            <p className="text-gray-600 mt-2">Fill out the form to apply for a new water connection</p>
          </div>

          {renderStepIndicator()}

          <div className="mb-8">{renderCurrentStep()}</div>

          <div className="flex justify-between">
            <Button variant="outline" onClick={prevStep} disabled={currentStep === 1} className="flex items-center">
              <ChevronLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>

            <Button
              onClick={nextStep}
              disabled={currentStep === 5}
              className="flex items-center bg-blue-600 hover:bg-blue-700"
            >
              Next
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
