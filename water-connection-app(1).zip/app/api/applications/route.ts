import { type NextRequest, NextResponse } from "next/server"
import { pool } from "@/lib/db"
import jwt from "jsonwebtoken"

function generateApplicationNumber() {
  const year = new Date().getFullYear()
  const random = Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, "0")
  return `WC${year}${random}`
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    const token = authHeader?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ error: "Access token required" }, { status: 401 })
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || "fallback-secret") as any
    const userId = decoded.userId

    const {
      propertyType,
      propertyUse,
      address,
      city,
      district,
      ownershipStatus,
      connectionType,
      expectedUsage,
      additionalInfo,
    } = await request.json()

    const applicationNumber = generateApplicationNumber()

    const result = await pool.query(
      `INSERT INTO applications (
        user_id, application_number, property_type, property_use, address, city, 
        district, ownership_status, connection_type, expected_usage, additional_info
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) 
      RETURNING *`,
      [
        userId,
        applicationNumber,
        propertyType,
        propertyUse,
        address,
        city,
        district,
        ownershipStatus,
        connectionType,
        expectedUsage,
        additionalInfo,
      ],
    )

    const application = result.rows[0]

    // Add initial status history
    await pool.query(
      `INSERT INTO application_status_history (application_id, status, comment, changed_by) 
       VALUES ($1, $2, $3, $4)`,
      [application.id, "pending", "Application submitted", "system"],
    )

    return NextResponse.json(
      {
        message: "Application submitted successfully",
        application: {
          id: application.id,
          applicationNumber: application.application_number,
          status: application.status,
          createdAt: application.created_at,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Application submission error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    const token = authHeader?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ error: "Access token required" }, { status: 401 })
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || "fallback-secret") as any
    const userId = decoded.userId

    const result = await pool.query(
      `SELECT a.*, 
              COALESCE(SUM(p.amount), 0) as total_paid,
              COUNT(d.id) as document_count
       FROM applications a
       LEFT JOIN payments p ON a.id = p.application_id AND p.payment_status = 'completed'
       LEFT JOIN documents d ON a.id = d.application_id
       WHERE a.user_id = $1
       GROUP BY a.id
       ORDER BY a.created_at DESC`,
      [userId],
    )

    return NextResponse.json({
      applications: result.rows.map((app) => ({
        id: app.id,
        applicationNumber: app.application_number,
        propertyType: app.property_type,
        address: app.address,
        city: app.city,
        status: app.status,
        totalPaid: Number.parseFloat(app.total_paid),
        documentCount: Number.parseInt(app.document_count),
        createdAt: app.created_at,
        updatedAt: app.updated_at,
      })),
    })
  } catch (error) {
    console.error("Get applications error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
