import { Button } from "@/components/ui/button"
import Link from "next/link"

export function HeroSection() {
  return (
    <section className="bg-white py-20">
      <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">
          Water Connection <span className="text-blue-600">Made Simple</span>
        </h1>

        <p className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto">
          Apply for new water connections, track your application status, and manage payments all in one place.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/apply">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 px-8 py-3">
              Get Started →
            </Button>
          </Link>
          <Link href="/about">
            <Button variant="outline" size="lg" className="px-8 py-3">
              Learn More
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
