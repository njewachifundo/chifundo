"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Plus,
  FileText,
  CreditCard,
  HelpCircle,
  Settings,
  MessageCircle,
  Users,
  Shield,
  Database,
  BarChart3,
  DollarSign,
  TrendingUp,
} from "lucide-react"

interface SidebarProps {
  userRole?: "customer" | "admin" | "manager" | "staff"
}

export function Sidebar({ userRole = "customer" }: SidebarProps) {
  const pathname = usePathname()

  const customerMenuItems = [
    { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
    { icon: Plus, label: "New Connection", href: "/application/new" },
    { icon: FileText, label: "Application Status", href: "/applications" },
    { icon: CreditCard, label: "Payment History", href: "/payments" },
    { icon: HelpCircle, label: "Support Center", href: "/support" },
    { icon: Settings, label: "Profile Settings", href: "/profile" },
    { icon: MessageCircle, label: "FAQs", href: "/faqs" },
    { icon: MessageCircle, label: "Contact NRWB", href: "/contact" },
  ]

  const adminMenuItems = [
    { icon: LayoutDashboard, label: "System Dashboard", href: "/admin/dashboard" },
    { icon: Users, label: "User Management", href: "/admin/users" },
    { icon: Settings, label: "System Configuration", href: "/admin/config" },
    { icon: Shield, label: "Security Settings", href: "/admin/security" },
    { icon: FileText, label: "Audit Logs", href: "/admin/logs" },
    { icon: Database, label: "Backup & Restore", href: "/admin/backup" },
    { icon: BarChart3, label: "API Integration", href: "/admin/api" },
    { icon: FileText, label: "System Reports", href: "/admin/reports" },
  ]

  const managerMenuItems = [
    { icon: LayoutDashboard, label: "Executive Dashboard", href: "/manager/dashboard" },
    { icon: BarChart3, label: "Strategic Reports", href: "/manager/reports" },
    { icon: TrendingUp, label: "Performance Analytics", href: "/manager/analytics" },
    { icon: DollarSign, label: "Resource Allocation", href: "/manager/resources" },
    { icon: Shield, label: "System Audit", href: "/manager/audit" },
    { icon: DollarSign, label: "Financial Overview", href: "/manager/finance" },
  ]

  const getMenuItems = () => {
    switch (userRole) {
      case "admin":
        return adminMenuItems
      case "manager":
        return managerMenuItems
      case "staff":
        return customerMenuItems // Staff can use customer interface for now
      default:
        return customerMenuItems
    }
  }

  const menuItems = getMenuItems()

  return (
    <div className="w-64 bg-slate-900 text-white min-h-screen">
      <div className="p-6">
        <Link href="/" className="text-2xl font-bold text-blue-400">
          NRWB
        </Link>
      </div>

      <nav className="mt-8">
        <div className="px-4 mb-4">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">MAIN MENU</p>
        </div>

        <div className="space-y-1 px-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors",
                  isActive ? "bg-blue-600 text-white" : "text-gray-300 hover:bg-slate-800 hover:text-white",
                )}
              >
                <Icon className="mr-3 h-5 w-5" />
                {item.label}
              </Link>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
