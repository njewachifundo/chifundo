import { Card, CardContent } from "@/components/ui/card"
import { UserPlus, FileText, TrendingUp } from "lucide-react"

export function HowItWorks() {
  const steps = [
    {
      number: "01",
      title: "Create Account",
      description: "Register with your details to access our services and application forms.",
      icon: UserPlus,
    },
    {
      number: "02",
      title: "Submit Application",
      description: "Fill out the application form with your property details and required documents.",
      icon: FileText,
    },
    {
      number: "03",
      title: "Track Progress",
      description: "Track your application status in real-time and receive updates at every step.",
      icon: TrendingUp,
    },
  ]

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            How It <span className="text-blue-600">Works</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => {
            const Icon = step.icon
            return (
              <Card key={index} className="relative bg-white border-0 shadow-lg">
                <CardContent className="p-8 text-center">
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  <div className="mt-8">
                    <div className="text-6xl font-bold text-gray-100 mb-4">{step.number}</div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">{step.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{step.description}</p>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
