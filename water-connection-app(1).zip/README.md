# NRWB Water Connection Management System

A comprehensive water connection management system for the Northern Region Water Board, built with Next.js, PostgreSQL, and modern web technologies.

## 🚀 Features

- **Multi-step Application Process**: Streamlined 5-step application form
- **User Role Management**: Customer, Staff, Admin, and Manager roles
- **Real-time Application Tracking**: Track application status and progress
- **Document Upload System**: Secure document management
- **Payment Processing**: Integrated payment tracking
- **Admin Dashboard**: Comprehensive system management
- **Executive Analytics**: Business intelligence and reporting
- **Responsive Design**: Works on all devices

## 🛠️ Tech Stack

- **Frontend**: Next.js 14, React, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, Node.js
- **Database**: PostgreSQL
- **Authentication**: JWT tokens
- **UI Components**: Radix UI, shadcn/ui
- **Styling**: Tailwind CSS
- **Icons**: Lucide React

## 📦 Quick Deployment

### Deploy to Vercel (Recommended)

1. **Fork this repository**
2. **Connect to Vercel**:
   - Go to [vercel.com](https://vercel.com)
   - Import your GitHub repository
   - Vercel will auto-detect Next.js

3. **Add Environment Variables** in Vercel dashboard:
   \`\`\`
   DATABASE_URL=your_postgresql_connection_string
   JWT_SECRET=your-super-secret-jwt-key
   NEXTAUTH_SECRET=your-nextauth-secret
   \`\`\`

4. **Set up PostgreSQL Database**:
   - Use Vercel Postgres, or
   - Use external provider (Neon, Supabase, etc.)

5. **Deploy**: Vercel will automatically build and deploy

### Deploy to Railway

1. **Connect GitHub repository**
2. **Add PostgreSQL service**
3. **Set environment variables**
4. **Deploy automatically**

### Deploy to Render

1. **Connect GitHub repository**
2. **Choose "Web Service"**
3. **Add PostgreSQL database**
4. **Set environment variables**
5. **Deploy**

## 🗄️ Database Setup

### Automatic Setup (Recommended)
The app includes migration and seeding scripts:

\`\`\`bash
# Run migrations
npm run db:migrate

# Seed with demo data
npm run db:seed
\`\`\`

### Manual Setup
Run the SQL scripts in order:
1. `scripts/01-create-database.sql`
2. `scripts/02-seed-data.sql`

## 🔐 Demo Credentials

After seeding, use these credentials:

- **Customer**: `customer1@nrwb.com` / `password1`
- **Staff**: `staff1@nrwb.com` / `password1`
- **Admin**: `admin1@nrwb.com` / `password1`
- **Manager**: `manager1@nrwb.com` / `password1`

## 🏃‍♂️ Local Development

1. **Clone the repository**:
   \`\`\`bash
   git clone <your-repo-url>
   cd nrwb-water-connection
   \`\`\`

2. **Install dependencies**:
   \`\`\`bash
   npm install
   \`\`\`

3. **Set up environment variables**:
   \`\`\`bash
   cp .env.example .env.local
   # Edit .env.local with your database credentials
   \`\`\`

4. **Set up database**:
   \`\`\`bash
   npm run db:migrate
   npm run db:seed
   \`\`\`

5. **Start development server**:
   \`\`\`bash
   npm run dev
   \`\`\`

6. **Open**: http://localhost:3000

## 📁 Project Structure

\`\`\`
├── app/                    # Next.js app directory
│   ├── api/               # API routes
│   ├── admin/             # Admin dashboard
│   ├── manager/           # Manager dashboard
│   ├── application/       # Application forms
│   └── dashboard/         # Customer dashboard
├── components/            # Reusable components
│   ├── ui/               # shadcn/ui components
│   ├── header.tsx        # Site header
│   └── sidebar.tsx       # Navigation sidebar
├── lib/                  # Utility functions
│   └── db.js            # Database connection
├── scripts/             # Database scripts
│   ├── migrate.js       # Database migrations
│   └── seed.js          # Sample data seeding
└── public/              # Static assets
\`\`\`

## 🔧 Configuration

### Environment Variables

\`\`\`env
# Database
DATABASE_URL=postgresql://username:password@hostname:5432/database_name

# Authentication
JWT_SECRET=your-super-secret-jwt-key
NEXTAUTH_SECRET=your-nextauth-secret

# App
NEXT_PUBLIC_APP_URL=https://your-domain.com
NODE_ENV=production
\`\`\`

### Database Schema

The system includes:
- **Users**: Customer accounts and staff
- **Applications**: Water connection requests
- **Payments**: Payment tracking
- **Documents**: File uploads
- **Status History**: Application progress tracking

## 🚀 Production Deployment

### Pre-deployment Checklist

- [ ] Set strong JWT secrets
- [ ] Configure production database
- [ ] Set up file storage (for document uploads)
- [ ] Configure email notifications
- [ ] Set up monitoring and logging
- [ ] Test all user flows
- [ ] Verify security settings

### Performance Optimization

- Built-in Next.js optimizations
- Database indexing
- Image optimization
- Code splitting
- Static generation where possible

## 🔒 Security Features

- JWT-based authentication
- Password hashing with bcrypt
- SQL injection protection
- CORS configuration
- Input validation
- Role-based access control

## 📱 Mobile Responsive

The application is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile phones
- All modern browsers

## 🆘 Support

For deployment help or issues:
1. Check the deployment logs
2. Verify environment variables
3. Test database connection
4. Review the documentation

## 📄 License

This project is licensed under the MIT License.

---

**Ready to deploy!** 🚀

Choose your preferred hosting platform and follow the deployment steps above.
